
public class VIP{

    public static void main(String[] args){
         int vip_key = 123456789;
         System.out.println("vip_key : " + vip_key);
    }
}
